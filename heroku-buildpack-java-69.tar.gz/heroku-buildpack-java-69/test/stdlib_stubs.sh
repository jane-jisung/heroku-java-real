#!/usr/bin/env bash

export BUILDPACK_LOG_FILE="$(mktemp)"

mmeasure() {
  :
}

mcount() {
  :
}

mtime() {
  :
}

mnow() {
  date +%s%3N
}

nowms() {
  date +%s%3N
}
