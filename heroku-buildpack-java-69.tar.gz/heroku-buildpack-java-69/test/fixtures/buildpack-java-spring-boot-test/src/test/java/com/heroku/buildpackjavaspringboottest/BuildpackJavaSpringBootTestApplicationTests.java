package com.heroku.buildpackjavaspringboottest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BuildpackJavaSpringBootTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
