package com.heroku.buildpackjavaspringboottest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BuildpackJavaSpringBootTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(BuildpackJavaSpringBootTestApplication.class, args);
	}

}
