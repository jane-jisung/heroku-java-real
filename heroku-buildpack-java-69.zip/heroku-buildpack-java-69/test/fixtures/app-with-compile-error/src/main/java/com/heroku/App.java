package com.heroku;

public class App {
    public static void main(String[] args) {
        String message = 42
        System.out.println(message);
    }
}
